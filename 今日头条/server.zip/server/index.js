/**
 * @file 入口文件
 *
 */
var http = require('http');
var enhancer = require('./enhancer');
var mockData = require('./mock');

var app = http.createServer(function (req, res) {
	res.setHeader("Access-Control-Allow-Origin","*");
	res.setHeader("Content-Type","application/json;charset=UTF-8");
	app.handle(req, res);
});

enhancer.decorateApp(app);

app.route('/', function (req, res) {
    res.send('mock数据服务器');
});

for(route in mockData){
    console.log(route)
    app.route(route, function (req, res) {
        res.send(JSON.stringify(mockData[route]));
    });
}


app.listen(9999, '0.0.0.0');
